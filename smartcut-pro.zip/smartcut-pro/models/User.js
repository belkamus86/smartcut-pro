// نموذج المستخدم (بدون قاعدة بيانات - للتجربة)
// للإنتاج، استخدم MongoDB أو PostgreSQL

const users = [];
let nextUserId = 1;

// دوال مساعدة
const UserModel = {
    // إنشاء مستخدم جديد
    create: (userData) => {
        const newUser = {
            id: nextUserId++,
            email: userData.email,
            password: userData.password,
            name: userData.name,
            plan: 'free',
            usage: {
                daily: 0,
                lastReset: new Date().toISOString().split('T')[0],
                total: 0
            },
            createdAt: new Date(),
            cpaCompleted: []
        };
        users.push(newUser);
        return newUser;
    },
    
    // البحث عن مستخدم بالبريد الإلكتروني
    findByEmail: (email) => {
        return users.find(u => u.email === email);
    },
    
    // البحث عن مستخدم بالـ ID
    findById: (id) => {
        return users.find(u => u.id === id);
    },
    
    // تحديث مستخدم
    update: (id, data) => {
        const index = users.findIndex(u => u.id === id);
        if (index !== -1) {
            users[index] = { ...users[index], ...data };
            return users[index];
        }
        return null;
    },
    
    // الحصول على جميع المستخدمين
    getAll: () => {
        return users;
    },
    
    // إعادة تعيين الاستخدام اليومي لجميع المستخدمين
    resetDailyUsage: () => {
        const today = new Date().toISOString().split('T')[0];
        users.forEach(user => {
            if (user.usage.lastReset !== today) {
                user.usage.daily = 0;
                user.usage.lastReset = today;
            }
        });
    }
};

module.exports = UserModel;