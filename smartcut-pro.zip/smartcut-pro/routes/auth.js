const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const User = require('../models/User');

const router = express.Router();

// تسجيل حساب جديد
router.post('/signup', async (req, res) => {
    try {
        const { email, password, name } = req.body;
        
        // التحقق من صحة البيانات
        if (!email || !password || !name) {
            return res.status(400).json({ error: 'جميع الحقول مطلوبة' });
        }
        
        if (password.length < 6) {
            return res.status(400).json({ error: 'كلمة المرور يجب أن تكون 6 أحرف على الأقل' });
        }
        
        // التحقق من وجود المستخدم
        const existingUser = User.findByEmail(email);
        if (existingUser) {
            return res.status(400).json({ error: 'البريد الإلكتروني موجود بالفعل' });
        }
        
        // تشفير كلمة المرور
        const hashedPassword = await bcrypt.hash(password, 10);
        
        // إنشاء مستخدم جديد
        const user = User.create({
            email,
            password: hashedPassword,
            name
        });
        
        // إنشاء token
        const token = jwt.sign(
            { id: user.id, email: user.email, plan: user.plan },
            process.env.JWT_SECRET || 'secret123',
            { expiresIn: '7d' }
        );
        
        res.json({
            token,
            user: {
                id: user.id,
                email: user.email,
                name: user.name,
                plan: user.plan
            }
        });
        
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'حدث خطأ في الخادم' });
    }
});

// تسجيل الدخول
router.post('/login', async (req, res) => {
    try {
        const { email, password } = req.body;
        
        if (!email || !password) {
            return res.status(400).json({ error: 'البريد الإلكتروني وكلمة المرور مطلوبان' });
        }
        
        // البحث عن المستخدم
        const user = User.findByEmail(email);
        if (!user) {
            return res.status(401).json({ error: 'بريد إلكتروني أو كلمة مرور غير صحيحة' });
        }
        
        // التحقق من كلمة المرور
        const validPassword = await bcrypt.compare(password, user.password);
        if (!validPassword) {
            return res.status(401).json({ error: 'بريد إلكتروني أو كلمة مرور غير صحيحة' });
        }
        
        // إنشاء token جديد
        const token = jwt.sign(
            { id: user.id, email: user.email, plan: user.plan },
            process.env.JWT_SECRET || 'secret123',
            { expiresIn: '7d' }
        );
        
        res.json({
            token,
            user: {
                id: user.id,
                email: user.email,
                name: user.name,
                plan: user.plan
            }
        });
        
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'حدث خطأ في الخادم' });
    }
});

// الحصول على معلومات المستخدم الحالي
router.get('/me', require('../middleware/auth'), (req, res) => {
    const user = User.findById(req.user.id);
    if (!user) {
        return res.status(404).json({ error: 'مستخدم غير موجود' });
    }
    
    // تحديث الاستخدام اليومي
    const today = new Date().toISOString().split('T')[0];
    if (user.usage.lastReset !== today) {
        user.usage.daily = 0;
        user.usage.lastReset = today;
        User.update(user.id, user);
    }
    
    res.json({
        user: {
            id: user.id,
            email: user.email,
            name: user.name,
            plan: user.plan,
            usage: user.usage
        }
    });
});

module.exports = router;