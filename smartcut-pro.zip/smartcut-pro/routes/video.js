const express = require('express');
const multer = require('multer');
const fs = require('fs');
const path = require('path');
const { exec } = require('child_process');
const auth = require('../middleware/auth');
const User = require('../models/User');

const router = express.Router();

// إعداد تخزين الملفات
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        const uploadDir = path.join(__dirname, '../uploads');
        if (!fs.existsSync(uploadDir)) fs.mkdirSync(uploadDir);
        cb(null, uploadDir);
    },
    filename: (req, file, cb) => {
        const uniqueName = Date.now() + '-' + Math.round(Math.random() * 1E9) + path.extname(file.originalname);
        cb(null, uniqueName);
    }
});

const upload = multer({
    storage,
    limits: { fileSize: 500 * 1024 * 1024 }, // 500MB
    fileFilter: (req, file, cb) => {
        const allowedTypes = ['video/mp4', 'video/webm', 'video/quicktime', 'video/x-matroska'];
        if (allowedTypes.includes(file.mimetype)) {
            cb(null, true);
        } else {
            cb(new Error('نوع الملف غير مدعوم. يرجى رفع فيديو MP4 أو WebM'));
        }
    }
});

// رفع فيديو
router.post('/upload', auth, upload.single('video'), async (req, res) => {
    try {
        if (!req.file) {
            return res.status(400).json({ error: 'الرجاء رفع ملف فيديو' });
        }
        
        const user = User.findById(req.user.id);
        if (!user) {
            fs.unlinkSync(req.file.path);
            return res.status(404).json({ error: 'مستخدم غير موجود' });
        }
        
        // التحقق من حد الاستخدام اليومي
        const today = new Date().toISOString().split('T')[0];
        if (user.plan === 'free' && user.usage.daily >= 3) {
            fs.unlinkSync(req.file.path);
            return res.status(403).json({
                error: 'لقد استنفذت حد 3 فيديوهات يومياً. اشترك في الباقة المميزة!',
                upgrade: true
            });
        }
        
        // تحديث الاستخدام
        user.usage.daily++;
        user.usage.total++;
        User.update(user.id, user);
        
        res.json({
            success: true,
            file: {
                path: req.file.path,
                filename: req.file.filename,
                size: req.file.size,
                mimetype: req.file.mimetype
            },
            usage: {
                daily: user.usage.daily,
                total: user.usage.total,
                limit: user.plan === 'free' ? 3 : 'unlimited'
            }
        });
        
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: error.message });
    }
});

// تقطيع الفيديو
router.post('/split', auth, async (req, res) => {
    try {
        const { filePath, duration, startTime = 0 } = req.body;
        
        if (!filePath || !fs.existsSync(filePath)) {
            return res.status(400).json({ error: 'الملف غير موجود' });
        }
        
        const clipDuration = parseInt(duration) || 30;
        const outputDir = path.join(__dirname, '../temp', Date.now().toString());
        fs.mkdirSync(outputDir, { recursive: true });
        
        const outputPattern = path.join(outputDir, 'clip_%03d.mp4');
        
        // تقطيع الفيديو باستخدام FFmpeg
        await new Promise((resolve, reject) => {
            const cmd = `ffmpeg -i "${filePath}" -ss ${startTime} -f segment -segment_time ${clipDuration} -c copy "${outputPattern}" -y`;
            exec(cmd, (error, stdout, stderr) => {
                if (error) {
                    console.error('FFmpeg error:', stderr);
                    reject(error);
                } else {
                    resolve();
                }
            });
        });
        
        // جمع المقاطع المنتجة
        const clips = fs.readdirSync(outputDir)
            .filter(f => f.endsWith('.mp4'))
            .map((f, index) => ({
                index: index + 1,
                name: f,
                path: path.join(outputDir, f),
                size: fs.statSync(path.join(outputDir, f)).size
            }));
        
        res.json({
            success: true,
            clips: clips.map(c => ({
                ...c,
                downloadUrl: `/api/video/download/${c.path}`
            })),
            outputDir
        });
        
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'فشل تقطيع الفيديو: ' + error.message });
    }
});

// تحويل إلى MP3
router.post('/convert-to-mp3', auth, async (req, res) => {
    try {
        const { filePath } = req.body;
        
        if (!filePath || !fs.existsSync(filePath)) {
            return res.status(400).json({ error: 'الملف غير موجود' });
        }
        
        const outputPath = filePath.replace(/\.\w+$/, '.mp3');
        
        await new Promise((resolve, reject) => {
            const cmd = `ffmpeg -i "${filePath}" -q:a 0 -map a "${outputPath}" -y`;
            exec(cmd, (error, stdout, stderr) => {
                if (error) {
                    console.error('FFmpeg error:', stderr);
                    reject(error);
                } else {
                    resolve();
                }
            });
        });
        
        res.json({
            success: true,
            mp3: {
                path: outputPath,
                size: fs.statSync(outputPath).size,
                downloadUrl: `/api/video/download/${outputPath}`
            }
        });
        
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'فشل تحويل الفيديو إلى MP3: ' + error.message });
    }
});

// تحميل ملف
router.get('/download/*', (req, res) => {
    const filePath = req.params[0];
    
    if (!filePath || !fs.existsSync(filePath)) {
        return res.status(404).json({ error: 'الملف غير موجود' });
    }
    
    res.download(filePath, path.basename(filePath), (err) => {
        if (err) console.error('Download error:', err);
        
        // حذف الملف بعد 5 دقائق
        setTimeout(() => {
            if (fs.existsSync(filePath)) {
                fs.unlinkSync(filePath);
                console.log(`Deleted: ${filePath}`);
            }
        }, 5 * 60 * 1000);
    });
});

// حذف ملف (للمقاطع غير المرغوب فيها)
router.post('/delete', auth, async (req, res) => {
    try {
        const { filePath } = req.body;
        
        if (filePath && fs.existsSync(filePath)) {
            fs.unlinkSync(filePath);
            res.json({ success: true, message: 'تم حذف الملف' });
        } else {
            res.status(404).json({ error: 'الملف غير موجود' });
        }
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

module.exports = router;