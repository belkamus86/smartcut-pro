const express = require('express');
const auth = require('../middleware/auth');
const User = require('../models/User');

const router = express.Router();

// خطط الاشتراك
const plans = [
    {
        id: 'free',
        name: 'مجاني',
        price: 0,
        features: [
            '3 فيديوهات يومياً',
            'جودة 720p',
            'MP3 128kbps',
            'إعلانات'
        ]
    },
    {
        id: 'premium_monthly',
        name: 'مميز - شهري',
        price: 9.99,
        features: [
            'فيديوهات غير محدودة',
            'جودة 1080p + 4K',
            'MP3 320kbps',
            'بدون إعلانات',
            'معالجة أسرع',
            'دعم فني 24/7'
        ]
    },
    {
        id: 'premium_yearly',
        name: 'مميز - سنوي',
        price: 79.99,
        features: [
            'وفر 33%',
            'فيديوهات غير محدودة',
            'جودة 1080p + 4K',
            'MP3 320kbps',
            'بدون إعلانات',
            'معالجة أسرع',
            'دعم فني 24/7'
        ]
    }
];

// الحصول على قائمة الخطط
router.get('/plans', (req, res) => {
    res.json(plans);
});

// ترقية الحساب (محاكاة - لدمج Stripe حقيقية)
router.post('/upgrade', auth, async (req, res) => {
    try {
        const { planId, paymentMethod } = req.body;
        
        if (!planId || planId === 'free') {
            return res.status(400).json({ error: 'خطة غير صالحة' });
        }
        
        const user = User.findById(req.user.id);
        if (!user) {
            return res.status(404).json({ error: 'مستخدم غير موجود' });
        }
        
        // هنا يتم دمج Stripe أو PayPal
        // stripe.checkout.sessions.create({ ... })
        
        // محاكاة نجاح الدفع
        user.plan = 'premium';
        User.update(user.id, user);
        
        res.json({
            success: true,
            message: 'تم ترقية حسابك إلى الباقة المميزة بنجاح!',
            user: {
                id: user.id,
                email: user.email,
                name: user.name,
                plan: user.plan
            }
        });
        
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'فشلت عملية الترقية' });
    }
});

// إنشاء رابط دفع Stripe (للتكامل الحقيقي)
router.post('/create-checkout-session', auth, async (req, res) => {
    try {
        const { planId } = req.body;
        const plan = plans.find(p => p.id === planId);
        
        if (!plan || plan.price === 0) {
            return res.status(400).json({ error: 'خطة غير صالحة' });
        }
        
        // هنا يتم إنشاء جلسة دفع Stripe
        // const session = await stripe.checkout.sessions.create({ ... })
        
        res.json({
            url: `https://buy.stripe.com/test/${planId}` // رابط تجريبي
        });
        
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

module.exports = router;