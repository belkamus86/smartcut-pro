const jwt = require('jsonwebtoken');

module.exports = (req, res, next) => {
    try {
        const token = req.headers.authorization?.split(' ')[1];
        
        if (!token) {
            return res.status(401).json({ error: 'غير مصرح به. يرجى تسجيل الدخول' });
        }
        
        const decoded = jwt.verify(token, process.env.JWT_SECRET || 'secret123');
        req.user = decoded;
        next();
    } catch (error) {
        if (error.name === 'TokenExpiredError') {
            return res.status(401).json({ error: 'انتهت صلاحية الجلسة. يرجى تسجيل الدخول مرة أخرى' });
        }
        res.status(401).json({ error: 'token غير صالح' });
    }
};function authMiddleware(req, res, next) {