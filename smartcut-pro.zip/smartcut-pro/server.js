const express = require('express');
const cors = require('cors');
const fs = require('fs');
const path = require('path'); 

const { exec } = require('child_process');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const ytdl = require('ytdl-core');
require('dotenv').config();

const app = express();
app.use(cors());
app.use(express.json());
let users = [];

app.get('/api/user/me', (req, res) => {
    const authHeader = req.headers['authorization'];

    if (!authHeader) {
        return res.status(401).json({ error: 'Non autorisé' });
    }

    const token = authHeader.split(' ')[1];

    const user = users.find(u => u.token === token);

    if (!user) {
        return res.status(404).json({ error: 'Utilisateur introuvable' });
    }

    res.json({
        user: {
            email: user.email,
            name: user.name
        }
    });
});

app.post('/api/auth/signup', (req, res) => {
  const { email, password, name } = req.body;

  if (users.find(u => u.email === email)) {
    return res.status(400).json({ error: 'Email déjà utilisé' });
  }

  const user = {
    id: Date.now(),
    email,
    password,
    name,
    token: Date.now().toString()
  };

  users.push(user);

  res.json({ token: user.token, user });
});
app.post('/api/auth/login', (req, res) => {
  const { email, password } = req.body;

  const user = users.find(
    u => u.email === email && u.password === password
  );

  if (!user) {
    return res.status(400).json({ error: 'Invalid credentials' });
  }

  res.json({ token: user.token, user });
});
app.get('/api/user/me', (req, res) => {
  const authHeader = req.headers.authorization;

  if (!authHeader) {
    return res.status(401).json({ error: 'Non autorisé' });
  }

  const token = authHeader.split(' ')[1];

  const user = users.find(u => u.token === token);

  if (!user) {
    return res.status(404).json({ error: 'Utilisateur non trouvé' });
  }

  res.json({ user });
});

app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));

const multer = require('multer');

// التحقق من JWT_SECRET
if (!process.env.JWT_SECRET) {
    console.error('⚠️ JWT_SECRET not set in .env file! Using temporary secret.');
    process.env.JWT_SECRET = 'temp_secret_key_change_this_in_production';
}

// ========== إنشاء المجلدات ==========
const TEMP_DIR = path.join(__dirname, 'temp');
const UPLOADS_DIR = path.join(__dirname, 'uploads');
if (!fs.existsSync(TEMP_DIR)) fs.mkdirSync(TEMP_DIR, { recursive: true });
if (!fs.existsSync(UPLOADS_DIR)) fs.mkdirSync(UPLOADS_DIR, { recursive: true });

// تنظيف الملفات القديمة عند بدء التشغيل
setInterval(() => {
    const now = Date.now();
    const oneHour = 3600000;
    [TEMP_DIR, UPLOADS_DIR].forEach(dir => {
        if (fs.existsSync(dir)) {
            fs.readdirSync(dir).forEach(file => {
                const filePath = path.join(dir, file);
                try {
                    const stats = fs.statSync(filePath);
                    if (now - stats.mtimeMs > oneHour) {
                        if (stats.isFile()) fs.unlinkSync(filePath);
                        else if (stats.isDirectory()) fs.rmSync(filePath, { recursive: true, force: true });
                    }
                } catch (err) {
                    // تجاهل أخطاء الوصول
                }
            });
        }
    });
}, 3600000);

// ========== قاعدة بيانات بسيطة ==========

let nextUserId = 1;

// ========== YouTube Routes ==========
app.post('/api/youtube/info', async (req, res) => {
    try {
        const { url } = req.body;
        if (!url) return res.status(400).json({ error: 'URL required' });
        
        let videoUrl = url;
        if (videoUrl.includes('/shorts/')) {
            videoUrl = videoUrl.replace('/shorts/', '/watch?v=');
        }
        
        const info = await ytdl.getInfo(videoUrl);
        res.json({
            success: true,
            title: info.videoDetails.title,
            duration: parseInt(info.videoDetails.lengthSeconds),
            thumbnail: info.videoDetails.thumbnails[0]?.url || '',
            author: info.videoDetails.author.name
        });
    } catch (error) {
        console.error('YouTube info error:', error.message);
        res.status(500).json({ error: 'Invalid YouTube URL or video unavailable' });
    }
});

app.post('/api/youtube/download', async (req, res) => {
    let tempFile = null;
    try {
        let { url } = req.body;
        if (!url) return res.status(400).json({ error: 'URL required' });
        
        if (url.includes('/shorts/')) {
            url = url.replace('/shorts/', '/watch?v=');
        }
        
        const info = await ytdl.getInfo(url);
        const videoTitle = info.videoDetails.title.replace(/[^\w\s]/gi, '').substring(0, 50);
        tempFile = path.join(TEMP_DIR, `${Date.now()}_${videoTitle}.mp4`);
        
        await new Promise((resolve, reject) => {
            const stream = ytdl(url, { 
                quality: 'lowest',
                requestOptions: {
                    headers: {
                        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
                    }
                }
            });
            const writeStream = fs.createWriteStream(tempFile);
            
            let timeout = setTimeout(() => {
                stream.destroy();
                reject(new Error('Download timeout'));
            }, 120000);
            
            stream.on('error', reject);
            writeStream.on('error', reject);
            writeStream.on('finish', () => {
                clearTimeout(timeout);
                resolve();
            });
            stream.pipe(writeStream);
        });
        
        res.download(tempFile, `${videoTitle}.mp4`, (err) => {
            if (err) console.error('Download error:', err);
            setTimeout(() => {
                try {
                    if (tempFile && fs.existsSync(tempFile)) fs.unlinkSync(tempFile);
                } catch (cleanupErr) {
                    console.error('Cleanup error:', cleanupErr);
                }
            }, 60000);
        });

    } catch (error) {
        console.error('YouTube download error:', error.message);
        try {
            if (tempFile && fs.existsSync(tempFile)) fs.unlinkSync(tempFile);
        } catch (cleanupErr) {
            // تجاهل
        }
        res.status(500).json({ error: 'Download failed: ' + error.message });
    }
});

// ========== Auth Routes ==========
app.post('/api/auth/signup', async (req, res) => {
    try {
        const { email, password, name } = req.body;
        if (!email || !password) {
            return res.status(400).json({ error: 'Email and password required' });
        }
        
        if (users.find(u => u.email === email)) {
            return res.status(400).json({ error: 'Email already exists' });
        }
        
        const hashedPassword = await bcrypt.hash(password, 10);
        const user = {
            id: nextUserId++,
            email,
            password: hashedPassword,
            name: name || email.split('@')[0],
            plan: 'free',
            usage: { daily: 0, lastReset: new Date().toISOString().split('T')[0], total: 0 },
            createdAt: new Date()
        };
        users.push(user);
        
        const token = jwt.sign({ id: user.id, email: user.email }, process.env.JWT_SECRET, { expiresIn: '7d' });
        res.json({ token, user: { id: user.id, email: user.email, name: user.name, plan: user.plan } });
    } catch (error) {
        console.error('Signup error:', error.message);
        res.status(500).json({ error: error.message });
    }
});

app.post('/api/auth/login', async (req, res) => {
    try {
        const { email, password } = req.body;
        if (!email || !password) {
            return res.status(400).json({ error: 'Email and password required' });
        }
        
        const user = users.find(u => u.email === email);
        if (!user) return res.status(401).json({ error: 'Invalid credentials' });
        
        const validPassword = await bcrypt.compare(password, user.password);
        if (!validPassword) return res.status(401).json({ error: 'Invalid credentials' });
        
        const token = jwt.sign({ id: user.id, email: user.email }, process.env.JWT_SECRET, { expiresIn: '7d' });
        res.json({ token, user: { id: user.id, email: user.email, name: user.name, plan: user.plan } });
    } catch (error) {
        console.error('Login error:', error.message);
        res.status(500).json({ error: error.message });
    }
});

function authMiddleware(req, res, next) {
    const token = req.headers.authorization?.split(' ')[1];
    if (!token) return res.status(401).json({ error: 'Unauthorized' });
    
    try {
        const decoded = jwt.verify(token, process.env.JWT_SECRET);
        req.user = decoded;
        next();
    } catch (error) {
        res.status(401).json({ error: 'Invalid token' });
    }
}

// ========== Video Routes ==========
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, UPLOADS_DIR);
    },
    filename: (req, file, cb) => {
        const safeName = Date.now() + '-' + file.originalname.replace(/[^a-zA-Z0-9.-]/g, '_');
        cb(null, safeName);
    }
});

const upload = multer({ 
    storage, 
    limits: { fileSize: 500 * 1024 * 1024 },
    fileFilter: (req, file, cb) => {
        const allowedTypes = ['video/mp4', 'video/mpeg', 'video/quicktime', 'video/x-msvideo'];
        if (allowedTypes.includes(file.mimetype) || file.originalname.match(/\.(mp4|mov|avi|mkv)$/i)) {
            cb(null, true);
        } else {
            cb(new Error('Only video files are allowed'), false);
        }
    }
});

app.post('/api/video/upload', authMiddleware, upload.single('video'), async (req, res) => {
    try {
        if (!req.file) {
            return res.status(400).json({ error: 'No video file uploaded' });
        }
        
        const user = users.find(u => u.id === req.user.id);
        if (!user) {
            fs.unlinkSync(req.file.path);
            return res.status(401).json({ error: 'User not found' });
        }
        
        const today = new Date().toISOString().split('T')[0];
        
        if (user.usage.lastReset !== today) {
            user.usage.daily = 0;
            user.usage.lastReset = today;
        }
        
        if (user.plan === 'free' && user.usage.daily >= 3) {
            fs.unlinkSync(req.file.path);
            return res.status(403).json({ error: 'Daily limit reached (3 videos per day for free plan)' });
        }
        
        user.usage.daily++;
        user.usage.total++;
        
        res.json({ 
            success: true, 
            file: { 
                path: req.file.path, 
                filename: req.file.filename,
                originalName: req.file.originalname
            } 
        });
    } catch (error) {
        console.error('Upload error:', error.message);
        if (req.file && fs.existsSync(req.file.path)) {
            try { fs.unlinkSync(req.file.path); } catch(e) {}
        }
        res.status(500).json({ error: error.message });
    }
});

app.post('/api/video/split', authMiddleware, async (req, res) => {
    try {
        const { filePath, duration } = req.body;
        
        if (!filePath || !fs.existsSync(filePath)) {
            return res.status(400).json({ error: 'File not found' });
        }
        
        const clipDuration = parseInt(duration) || 30;
        if (clipDuration < 1 || clipDuration > 3600) {
            return res.status(400).json({ error: 'Duration must be between 1 and 3600 seconds' });
        }
        
        const outputDir = path.join(TEMP_DIR, Date.now().toString());
        fs.mkdirSync(outputDir, { recursive: true });
        
        const outputPattern = path.join(outputDir, 'clip_%03d.mp4');
        
        const cmd = `ffmpeg -i "${filePath}" -f segment -segment_time ${clipDuration} -c copy -reset_timestamps 1 "${outputPattern}" -y`;
        
        exec(cmd, { timeout: 300000 }, (error, stdout, stderr) => {
            if (error) {
                console.error('FFmpeg error:', stderr);
                // تنظيف المجلد في حالة الخطأ
                if (fs.existsSync(outputDir)) {
                    fs.rmSync(outputDir, { recursive: true, force: true });
                }
                return res.status(500).json({ error: 'Video splitting failed: ' + error.message });
            }
            
            // التحقق من وجود ملفات
            const files = fs.readdirSync(outputDir);
            if (files.length === 0) {
                fs.rmSync(outputDir, { recursive: true, force: true });
                return res.status(500).json({ error: 'No clips were created' });
            }
            
            const clips = files.map(f => ({
                name: f,
                path: path.join(outputDir, f),
                size: fs.statSync(path.join(outputDir, f)).size
            }));
            
            res.json({ success: true, clips, outputDir });
        });
        
    } catch (error) {
        console.error('Split error:', error.message);
        res.status(500).json({ error: error.message });
    }
});

// ========== تنظيف الملفات المؤقتة ==========
app.post('/api/cleanup', authMiddleware, (req, res) => {
    try {
        const { paths } = req.body;
        if (paths && Array.isArray(paths)) {
            paths.forEach(p => {
                try {
                    if (fs.existsSync(p)) {
                        const stat = fs.statSync(p);
                        if (stat.isDirectory()) {
                            fs.rmSync(p, { recursive: true, force: true });
                        } else {
                            fs.unlinkSync(p);
                        }
                    }
                } catch(e) {}
            });
        }
        res.json({ success: true });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// ========== Start Server ==========
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
    console.log(`✅ SmartCut Server running on http://localhost:${PORT}`);
    console.log(`📁 Temp directory: ${TEMP_DIR}`);
    console.log(`📁 Uploads directory: ${UPLOADS_DIR}`);
}); 